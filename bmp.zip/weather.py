import json
import requests
import datetime
import time





while True:
    date = datetime.datetime.now()
    response = requests.get("http://192.168.1.163/")
    info = json.loads(response.text)
    temp = info["temp"]
    bmp = info["bmp"]
    log = open('bmp.log', 'a')
    lo = open('temp.log', 'a')
    data = str(bmp)
    print(bmp)
    print(temp)	
    log.write(str(bmp) + '\n')
    log.close()
    lo.write(str(temp) + '\n')
    lo.close()
    time.sleep(60)
