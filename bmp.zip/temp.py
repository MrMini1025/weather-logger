import numpy as np
import io
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib
import time

matplotlib.style.use('ggplot')

fn = r'temp.log'
#s = pd.read_csv(fn, header=None, squeeze=True)
while True:
	with open(fn, encoding='utf-8') as f:
    		data = f.read()

	df = pd.read_csv(io.StringIO(data), header=None, squeeze=True)

	print(df)

	ax = df[df > 0].plot(figsize=(14,10))
	df[df < 0].plot(ax=ax)

	ax.get_figure().savefig('live_bmp.png')
	time.sleep(50)
